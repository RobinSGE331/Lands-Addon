package de.robin.landsboost.diplomacy.gui;

import de.robin.landsboost.diplomacy.manager.DiplomacyManager;
import de.robin.landsboost.diplomacy.model.DiplomacyRequest;
import de.robin.landsboost.hook.LandsHook;
import de.robin.landsboost.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class DiplomacyGui {
    private final DiplomacyManager diplomacyManager;
    private final LandsHook landsHook;

    public DiplomacyGui(DiplomacyManager diplomacyManager, LandsHook landsHook) {
        this.diplomacyManager = diplomacyManager;
        this.landsHook = landsHook;
    }

    public void open(Player player) {
        String nationId = landsHook.getNationId(player);
        if (nationId == null) return;
        Inventory inv = Bukkit.createInventory(new Holder(), 27, ColorUtil.colorize("&8Diplomacy"));
        ItemStack allies = new ItemStack(Material.LIME_BANNER);
        ItemMeta am = allies.getItemMeta();
        am.setDisplayName(ColorUtil.colorize("&aAllies"));
        am.setLore(diplomacyManager.allies(nationId).stream().map(s -> ColorUtil.colorize("&7- &f" + s)).toList());
        allies.setItemMeta(am);
        inv.setItem(10, allies);

        ItemStack enemies = new ItemStack(Material.RED_BANNER);
        ItemMeta em = enemies.getItemMeta();
        em.setDisplayName(ColorUtil.colorize("&cEnemies"));
        em.setLore(diplomacyManager.enemies(nationId).stream().map(s -> ColorUtil.colorize("&7- &f" + s)).toList());
        enemies.setItemMeta(em);
        inv.setItem(12, enemies);

        ItemStack pending = new ItemStack(Material.BOOK);
        ItemMeta pm = pending.getItemMeta();
        pm.setDisplayName(ColorUtil.colorize("&ePending Requests"));
        List<String> lore = diplomacyManager.incoming(nationId).stream().map(this::line).toList();
        pm.setLore(lore.isEmpty() ? List.of(ColorUtil.colorize("&7None")) : lore);
        pending.setItemMeta(pm);
        inv.setItem(14, pending);
        player.openInventory(inv);
    }

    private String line(DiplomacyRequest request) {
        return ColorUtil.colorize("&7- &f" + request.fromNationId() + " &8(" + request.type().name() + ")");
    }

    private static final class Holder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }
}
