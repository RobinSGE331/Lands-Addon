package de.robin.landsboost.diplomacy.manager;

import de.robin.landsboost.diplomacy.model.DiplomacyRelation;
import de.robin.landsboost.diplomacy.model.DiplomacyRequest;
import de.robin.landsboost.diplomacy.storage.DiplomacyStorage;

import java.util.*;
import java.util.stream.Collectors;

public class DiplomacyManager {
    private final DiplomacyStorage storage;

    public DiplomacyManager(DiplomacyStorage storage) {
        this.storage = storage;
    }

    public DiplomacyRelation getRelation(String nationA, String nationB) {
        if (nationA == null || nationB == null) return DiplomacyRelation.NEUTRAL;
        if (nationA.equalsIgnoreCase(nationB)) return DiplomacyRelation.ALLY;
        String key = key(nationA, nationB);
        return storage.relations().getOrDefault(key, DiplomacyRelation.NEUTRAL);
    }

    public void setRelation(String nationA, String nationB, DiplomacyRelation relation) {
        if (nationA == null || nationB == null || nationA.equalsIgnoreCase(nationB)) return;
        storage.relations().put(key(nationA, nationB), relation);
        storage.markDirty();
    }

    public void clearRelation(String nationA, String nationB) {
        storage.relations().remove(key(nationA, nationB));
        storage.markDirty();
    }

    public void createRequest(String from, String to, DiplomacyRelation type) {
        storage.requests().removeIf(r -> r.fromNationId().equalsIgnoreCase(from) && r.toNationId().equalsIgnoreCase(to) && r.type() == type);
        storage.requests().add(new DiplomacyRequest(from, to, type, System.currentTimeMillis()));
        storage.markDirty();
    }

    public boolean acceptRequest(String from, String to, DiplomacyRelation type) {
        Optional<DiplomacyRequest> req = storage.requests().stream()
                .filter(r -> r.fromNationId().equalsIgnoreCase(from) && r.toNationId().equalsIgnoreCase(to) && r.type() == type)
                .findFirst();
        if (req.isEmpty()) return false;
        storage.requests().remove(req.get());
        setRelation(from, to, type);
        return true;
    }

    public boolean denyRequest(String from, String to, DiplomacyRelation type) {
        boolean removed = storage.requests().removeIf(r -> r.fromNationId().equalsIgnoreCase(from) && r.toNationId().equalsIgnoreCase(to) && r.type() == type);
        if (removed) storage.markDirty();
        return removed;
    }

    public List<DiplomacyRequest> incoming(String nationId) {
        return storage.requests().stream().filter(r -> r.toNationId().equalsIgnoreCase(nationId)).collect(Collectors.toList());
    }

    public List<String> allies(String nationId) {
        return related(nationId, DiplomacyRelation.ALLY);
    }

    public List<String> enemies(String nationId) {
        return related(nationId, DiplomacyRelation.ENEMY);
    }

    private List<String> related(String nationId, DiplomacyRelation relation) {
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, DiplomacyRelation> entry : storage.relations().entrySet()) {
            if (entry.getValue() != relation) continue;
            String[] parts = entry.getKey().split("\\|");
            if (parts.length != 2) continue;
            if (parts[0].equalsIgnoreCase(nationId)) out.add(parts[1]);
            if (parts[1].equalsIgnoreCase(nationId)) out.add(parts[0]);
        }
        return out;
    }

    private String key(String a, String b) {
        return a.compareToIgnoreCase(b) <= 0 ? a + "|" + b : b + "|" + a;
    }

    public void shutdown() {
        storage.saveNow();
    }
}
