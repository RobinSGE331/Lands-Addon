package de.robin.landsboost.config;

import de.robin.landsboost.LandsNationBoostPlugin;
import de.robin.landsboost.model.BoostDefinition;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.potion.PotionEffectType;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

public class BoostConfigManager {

    private final LandsNationBoostPlugin plugin;
    private final Map<String, BoostDefinition> boosts = new HashMap<>();

    public BoostConfigManager(LandsNationBoostPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        boosts.clear();
        FileConfiguration config = plugin.getConfig();
        ConfigurationSection section = config.getConfigurationSection("boosts");
        if (section == null) {
            return;
        }

        for (String id : section.getKeys(false)) {
            ConfigurationSection boostSection = section.getConfigurationSection(id);
            if (boostSection == null) continue;

            Material material = Material.matchMaterial(boostSection.getString("material", "PAPER"));
            PotionEffectType effectType = PotionEffectType.getByName(boostSection.getString("effect-type", "SPEED").toUpperCase(Locale.ROOT));
            if (material == null || effectType == null) {
                plugin.getLogger().warning("Skipped boost '" + id + "' because material/effect is invalid.");
                continue;
            }

            BoostDefinition def = new BoostDefinition(
                    id.toLowerCase(Locale.ROOT),
                    boostSection.getString("display-name", id),
                    material,
                    boostSection.getStringList("lore"),
                    effectType,
                    Math.max(0, boostSection.getInt("amplifier", 0)),
                    Math.max(1, boostSection.getInt("duration-seconds", 60)),
                    boostSection.getBoolean("allow-stack-with-other-active", false),
                    Math.max(0, boostSection.getInt("cooldown-seconds", 0)),
                    boostSection.getString("permission", "")
            );
            boosts.put(def.id(), def);
        }
    }

    public Collection<BoostDefinition> getBoosts() {
        return Collections.unmodifiableCollection(boosts.values());
    }

    public Optional<BoostDefinition> findBoost(String id) {
        if (id == null) return Optional.empty();
        return Optional.ofNullable(boosts.get(id.toLowerCase(Locale.ROOT)));
    }

    public String msg(String key) {
        return plugin.getConfig().getString("messages." + key, key);
    }

    public String prefix() {
        return plugin.getConfig().getString("messages.prefix", "");
    }

    public String guiTitle() {
        return plugin.getConfig().getString("settings.gui-title", "&8Nation Boosts");
    }

    public int guiSize() {
        int configured = plugin.getConfig().getInt("settings.gui-size", 27);
        int clamped = Math.max(9, Math.min(54, configured));
        return clamped - (clamped % 9);
    }

    public boolean allowMultipleGlobal() {
        return plugin.getConfig().getBoolean("settings.allow-multiple-active-boosts", false);
    }

    public int asyncSaveDelayTicks() {
        return Math.max(20, plugin.getConfig().getInt("settings.storage.async-save-delay-ticks", 40));
    }

    public boolean boostAnnouncementEnabled() {
        return plugin.getConfig().getBoolean("boosts.announcements.enabled", true);
    }

    public boolean boostTitleEnabled() {
        return plugin.getConfig().getBoolean("boosts.announcements.title.enabled", true);
    }

    public String boostTitleText() {
        return plugin.getConfig().getString("boosts.announcements.title.title", "&6Nation Boost Activated!");
    }

    public String boostSubtitleText() {
        return plugin.getConfig().getString("boosts.announcements.title.subtitle", "&e%boost_name% &7is now active.");
    }

    public boolean boostActionbarEnabled() {
        return plugin.getConfig().getBoolean("boosts.announcements.actionbar.enabled", true);
    }

    public String boostActionbarText() {
        return plugin.getConfig().getString("boosts.announcements.actionbar.message", "&e%boost_name% &7activated.");
    }

    public boolean boostSoundEnabled() {
        return plugin.getConfig().getBoolean("boosts.announcements.sound.enabled", true);
    }

    public Sound boostSound() {
        return Sound.valueOf(plugin.getConfig().getString("boosts.announcements.sound.sound", "ENTITY_PLAYER_LEVELUP"));
    }
}
