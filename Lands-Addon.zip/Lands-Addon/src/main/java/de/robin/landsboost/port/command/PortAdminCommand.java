package de.robin.landsboost.port.command;

import org.bukkit.command.CommandSender;

public class PortAdminCommand {
    private final PortCommand portCommand;

    public PortAdminCommand(PortCommand portCommand) {
        this.portCommand = portCommand;
    }

    public void handle(CommandSender sender, String[] args) {
        portCommand.handleAdmin(sender, args);
    }
}
