package de.robin.landsboost.diplomacy.placeholder;

import de.robin.landsboost.diplomacy.manager.DiplomacyManager;
import de.robin.landsboost.diplomacy.model.DiplomacyRelation;
import de.robin.landsboost.hook.LandsHook;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class RelationPlaceholder extends PlaceholderExpansion {
    private final LandsHook landsHook;
    private final DiplomacyManager diplomacyManager;
    private final Map<String, Cached> cache = new ConcurrentHashMap<>();

    public RelationPlaceholder(LandsHook landsHook, DiplomacyManager diplomacyManager) {
        this.landsHook = landsHook;
        this.diplomacyManager = diplomacyManager;
    }

    @Override public @NotNull String getIdentifier() { return "landsnationboost"; }
    @Override public @NotNull String getAuthor() { return "robin"; }
    @Override public @NotNull String getVersion() { return "1.0.0"; }
    @Override public boolean persist() { return true; }

    @Override
    public String onPlaceholderRequest(Player viewer, @NotNull String params) {
        if (viewer == null || !params.startsWith("relation_")) return "";
        String targetName = params.substring("relation_".length());
        String key = viewer.getUniqueId() + "|" + targetName.toLowerCase();
        long now = System.currentTimeMillis();
        Cached cached = cache.get(key);
        if (cached != null && cached.until > now) return cached.value;

        OfflinePlayer target = Bukkit.getOfflinePlayerIfCached(targetName);
        if (target == null || target.getName() == null) {
            String out = "§7" + targetName;
            cache.put(key, new Cached(out, now + 2000L));
            return out;
        }
        Player onlineTarget = Bukkit.getPlayer(target.getUniqueId());
        if (onlineTarget == null) {
            String out = "§7" + target.getName();
            cache.put(key, new Cached(out, now + 2000L));
            return out;
        }

        String viewerNation = landsHook.getNationId(viewer);
        String targetNation = landsHook.getNationId(onlineTarget);
        String out;
        if (viewerNation == null || targetNation == null) out = "§f" + onlineTarget.getName();
        else if (viewerNation.equalsIgnoreCase(targetNation)) out = "§a" + onlineTarget.getName();
        else {
            DiplomacyRelation relation = diplomacyManager.getRelation(viewerNation, targetNation);
            out = switch (relation) {
                case ALLY -> "§9" + onlineTarget.getName();
                case ENEMY -> "§c" + onlineTarget.getName();
                default -> "§f" + onlineTarget.getName();
            };
        }
        cache.put(key, new Cached(out, now + 2000L));
        return out;
    }

    private record Cached(String value, long until) {}
}
