package de.robin.landsboost.diplomacy.model;

public enum DiplomacyRelation {
    NEUTRAL,
    ALLY,
    ENEMY
}
