package de.robin.landsboost.port.manager;

import de.robin.landsboost.LandsNationBoostPlugin;
import de.robin.landsboost.port.model.Port;
import de.robin.landsboost.util.ColorUtil;
import de.robin.landsboost.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class PortTravelManager {
    private final LandsNationBoostPlugin plugin;
    private final PortConfig config;
    private final EconomyManager economy;
    private final PortSafeLocationFinder safeLocationFinder;
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, PendingTravel> pending = new ConcurrentHashMap<>();

    public PortTravelManager(LandsNationBoostPlugin plugin, PortConfig config, EconomyManager economy, PortSafeLocationFinder safeLocationFinder) {
        this.plugin = plugin;
        this.config = config;
        this.economy = economy;
        this.safeLocationFinder = safeLocationFinder;
    }

    public String startTravel(Player player, Port port) {
        if (isOnCooldown(player) && !player.hasPermission("landsnationboost.port.bypass.cooldown")) {
            return "cooldown";
        }

        double cost = port.getTravelCost();
        boolean bypassCost = player.hasPermission("landsnationboost.port.bypass.cost") || player.hasPermission("landsnationboost.port.admin");
        if (config.economyEnabled() && economy.isAvailable() && !bypassCost && !economy.charge(player, cost)) {
            return "cannot-pay";
        }

        int warmup = Math.max(0, config.warmupSeconds());
        if (warmup == 0) {
            return performTeleport(player, port) ? "teleported" : "unsafe-destination";
        }

        cancelPending(player.getUniqueId());
        Location start = player.getLocation().clone();
        int taskId = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            pending.remove(player.getUniqueId());
            performTeleport(player, port);
        }, warmup * 20L).getTaskId();
        pending.put(player.getUniqueId(), new PendingTravel(taskId, start));
        player.sendMessage(ColorUtil.colorize(config.msg("warmup-start")
                .replace("%port%", port.getName())
                .replace("%time%", String.valueOf(warmup))));
        return "warmup";
    }

    public boolean performTeleport(Player player, Port port) {
        Location location = safeLocationFinder.findSafe(port.toLocation(), config.safeRadius());
        if (location == null) return false;
        player.teleport(location);
        if (!player.hasPermission("landsnationboost.port.bypass.cooldown")) {
            cooldowns.put(player.getUniqueId(), System.currentTimeMillis() + (config.cooldownSeconds() * 1000L));
        }
        player.playSound(player.getLocation(), config.travelSound(), 1f, 1f);
        player.spawnParticle(config.particle(), player.getLocation(), 20, 0.4, 0.8, 0.4, 0.01);
        player.sendMessage(ColorUtil.colorize(config.msg("teleported").replace("%port%", port.getName())));
        return true;
    }

    public boolean isOnCooldown(Player player) {
        Long until = cooldowns.get(player.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    public String cooldownText(Player player) {
        Long until = cooldowns.get(player.getUniqueId());
        long sec = until == null ? 0 : Math.max(0, (until - System.currentTimeMillis()) / 1000L);
        return TimeUtil.formatSeconds(sec);
    }

    public void cancelIfMoved(Player player, Location from, Location to) {
        if (!config.cancelOnMove() || to == null || from == null) return;
        if (from.getBlockX() != to.getBlockX() || from.getBlockZ() != to.getBlockZ()) cancelPending(player.getUniqueId(), player);
    }

    public void cancelIfDamage(Player player) {
        if (config.cancelOnDamage()) cancelPending(player.getUniqueId(), player);
    }

    public void cancelIfTeleport(Player player) {
        if (config.cancelOnTeleport()) cancelPending(player.getUniqueId(), player);
    }

    public void cancelPending(UUID playerId) {
        PendingTravel pendingTravel = pending.remove(playerId);
        if (pendingTravel != null) Bukkit.getScheduler().cancelTask(pendingTravel.taskId);
    }

    private void cancelPending(UUID playerId, Player player) {
        PendingTravel pendingTravel = pending.remove(playerId);
        if (pendingTravel != null) {
            Bukkit.getScheduler().cancelTask(pendingTravel.taskId);
            player.sendMessage(ColorUtil.colorize(config.msg("warmup-cancelled")));
        }
    }

    public void shutdown() {
        for (PendingTravel value : pending.values()) {
            Bukkit.getScheduler().cancelTask(value.taskId);
        }
        pending.clear();
    }

    private record PendingTravel(int taskId, Location start) {}
}
