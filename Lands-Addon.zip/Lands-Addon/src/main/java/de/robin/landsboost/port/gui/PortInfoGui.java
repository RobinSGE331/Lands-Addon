package de.robin.landsboost.port.gui;

import de.robin.landsboost.port.model.Port;
import de.robin.landsboost.util.ColorUtil;
import org.bukkit.entity.Player;

import java.text.SimpleDateFormat;
import java.util.Date;

public class PortInfoGui {
    public void open(Player player, Port port) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        player.sendMessage(ColorUtil.colorize("&8----- &bPort Info &8-----"));
        player.sendMessage(ColorUtil.colorize("&7Name: &f" + port.getName()));
        player.sendMessage(ColorUtil.colorize("&7ID: &f" + port.getId()));
        player.sendMessage(ColorUtil.colorize("&7Owner Land: &f" + port.getOwnerLandName() + " &8(" + port.getOwnerLandId() + ")"));
        player.sendMessage(ColorUtil.colorize("&7Owner Nation: &f" + port.getOwnerNationName() + " &8(" + port.getOwnerNationId() + ")"));
        player.sendMessage(ColorUtil.colorize("&7Location: &f" + (int) port.getX() + ", " + (int) port.getY() + ", " + (int) port.getZ()));
        player.sendMessage(ColorUtil.colorize("&7World: &f" + port.getWorld()));
        player.sendMessage(ColorUtil.colorize("&7Access: &f" + port.getAccessType().name()));
        player.sendMessage(ColorUtil.colorize("&7Cost: &f" + port.getTravelCost()));
        player.sendMessage(ColorUtil.colorize("&7Enabled: " + (port.isEnabled() ? "&aYes" : "&cNo")));
        player.sendMessage(ColorUtil.colorize("&7Created At: &f" + format.format(new Date(port.getCreatedAt()))));
    }
}
