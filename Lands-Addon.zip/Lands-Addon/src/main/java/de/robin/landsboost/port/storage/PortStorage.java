package de.robin.landsboost.port.storage;

import de.robin.landsboost.LandsNationBoostPlugin;
import de.robin.landsboost.port.model.Port;
import de.robin.landsboost.port.model.PortAccessType;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class PortStorage {
    private final LandsNationBoostPlugin plugin;
    private final File file;
    private final FileConfiguration yaml;
    private final Map<UUID, Port> byId = new ConcurrentHashMap<>();
    private volatile boolean dirty;
    private int saveTask = -1;

    public PortStorage(LandsNationBoostPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "ports.yml");
        this.yaml = YamlConfiguration.loadConfiguration(file);
        load();
    }

    public Collection<Port> getAll() {
        return byId.values();
    }

    public Port getById(UUID id) {
        return byId.get(id);
    }

    public void put(Port port) {
        byId.put(port.getId(), port);
        markDirty();
    }

    public void remove(UUID id) {
        byId.remove(id);
        markDirty();
    }

    public void markDirty() {
        dirty = true;
        if (saveTask != -1) return;
        saveTask = Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, this::saveIfDirty, 40L).getTaskId();
    }

    public synchronized void saveNow() {
        yaml.set("ports", null);
        for (Port p : byId.values()) {
            String base = "ports." + p.getName().toLowerCase();
            yaml.set(base + ".id", p.getId().toString());
            yaml.set(base + ".name", p.getName());
            yaml.set(base + ".world", p.getWorld());
            yaml.set(base + ".x", p.getX());
            yaml.set(base + ".y", p.getY());
            yaml.set(base + ".z", p.getZ());
            yaml.set(base + ".yaw", p.getYaw());
            yaml.set(base + ".pitch", p.getPitch());
            yaml.set(base + ".owner-land-id", p.getOwnerLandId());
            yaml.set(base + ".owner-land-name", p.getOwnerLandName());
            yaml.set(base + ".owner-nation-id", p.getOwnerNationId());
            yaml.set(base + ".owner-nation-name", p.getOwnerNationName());
            yaml.set(base + ".access-type", p.getAccessType().name());
            yaml.set(base + ".enabled", p.isEnabled());
            yaml.set(base + ".travel-cost", p.getTravelCost());
            yaml.set(base + ".created-by", p.getCreatedBy().toString());
            yaml.set(base + ".created-at", p.getCreatedAt());
        }
        try {
            yaml.save(file);
        } catch (IOException ignored) {
        } finally {
            dirty = false;
            saveTask = -1;
        }
    }

    private void saveIfDirty() {
        if (!dirty) {
            saveTask = -1;
            return;
        }
        saveNow();
    }

    private void load() {
        ConfigurationSection section = yaml.getConfigurationSection("ports");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(key);
            if (s == null) continue;
            UUID id = UUID.fromString(s.getString("id"));
            Port p = new Port(id);
            p.setName(s.getString("name", key));
            p.setWorld(s.getString("world", "world"));
            p.setX(s.getDouble("x"));
            p.setY(s.getDouble("y"));
            p.setZ(s.getDouble("z"));
            p.setYaw((float) s.getDouble("yaw"));
            p.setPitch((float) s.getDouble("pitch"));
            p.setOwnerLandId(s.getString("owner-land-id", ""));
            p.setOwnerLandName(s.getString("owner-land-name", ""));
            p.setOwnerNationId(s.getString("owner-nation-id", ""));
            p.setOwnerNationName(s.getString("owner-nation-name", ""));
            p.setAccessType(PortAccessType.fromString(s.getString("access-type", "NATION")));
            p.setEnabled(s.getBoolean("enabled", true));
            p.setTravelCost(s.getDouble("travel-cost", 100.0));
            p.setCreatedBy(UUID.fromString(s.getString("created-by", "00000000-0000-0000-0000-000000000000")));
            p.setCreatedAt(s.getLong("created-at", System.currentTimeMillis()));
            byId.put(id, p);
        }
    }
}
