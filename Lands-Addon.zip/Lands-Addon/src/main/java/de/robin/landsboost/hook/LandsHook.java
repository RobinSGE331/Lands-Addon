package de.robin.landsboost.hook;

import de.robin.landsboost.LandsNationBoostPlugin;
import me.angeschossen.lands.api.LandsIntegration;
import me.angeschossen.lands.api.land.Land;
import me.angeschossen.lands.api.nation.Nation;
import me.angeschossen.lands.api.player.LandPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class LandsHook {
    private static final long LOOKUP_CACHE_TTL_MS = 2_500L;

    private final LandsIntegration landsApi;
    private final Map<UUID, CachedNation> nationByPlayerCache = new ConcurrentHashMap<>();

    public LandsHook(LandsNationBoostPlugin plugin) {
        LandsIntegration integration = null;
        if (Bukkit.getPluginManager().getPlugin("Lands") != null) {
            try {
                integration = LandsIntegration.of(plugin);
            } catch (Exception ignored) {
                // Keep silent to avoid warning spam. Commands will handle unavailable hook.
            }
        }
        this.landsApi = integration;
    }

    public boolean isAvailable() {
        return landsApi != null;
    }

    @Nullable
    public String getNationId(Player player) {
        if (!isAvailable() || player == null) return null;

        long now = System.currentTimeMillis();
        CachedNation cached = nationByPlayerCache.get(player.getUniqueId());
        if (cached != null && cached.expiresAt > now) {
            return cached.nationId;
        }

        try {
            LandPlayer landPlayer = landsApi.getLandPlayer(player.getUniqueId());
            if (landPlayer == null) {
                cache(player.getUniqueId(), null, now);
                return null;
            }

            Land editLand = landPlayer.getEditLand(false);
            if (editLand != null && editLand.getNation() != null) {
                String nationId = editLand.getNation().getULID().toString();
                cache(player.getUniqueId(), nationId, now);
                return nationId;
            }

            Collection<? extends Land> lands = landPlayer.getLands();
            for (Land land : lands) {
                Nation nation = land.getNation();
                if (nation != null) {
                    String nationId = nation.getULID().toString();
                    cache(player.getUniqueId(), nationId, now);
                    return nationId;
                }
            }
        } catch (Exception ignored) {
            // Silent by design, caller handles null result with user-friendly message.
        }

        cache(player.getUniqueId(), null, now);
        return null;
    }

    public Set<Player> getOnlineNationMembers(String nationId) {
        if (!isAvailable() || nationId == null) return Collections.emptySet();

        Set<Player> players = new HashSet<>();
        for (Player online : Bukkit.getOnlinePlayers()) {
            String currentNationId = getNationId(online);
            if (nationId.equalsIgnoreCase(currentNationId)) {
                players.add(online);
            }
        }
        return players;
    }

    public OfflinePlayer findOfflinePlayer(String name) {
        return Bukkit.getOfflinePlayer(name);
    }

    @Nullable
    public String getLandIdAt(Location location) {
        if (!isAvailable() || location == null) return null;
        try {
            Land land = landsApi.getLandByUnloadedChunk(location.getWorld(), location.getChunk().getX(), location.getChunk().getZ());
            return land == null ? null : land.getULID().toString();
        } catch (Exception ignored) {
            return null;
        }
    }

    public String getLandNameAt(Location location) {
        if (!isAvailable() || location == null) return "Unknown Land";
        try {
            Land land = landsApi.getLandByUnloadedChunk(location.getWorld(), location.getChunk().getX(), location.getChunk().getZ());
            return land == null ? "No Land" : land.getName();
        } catch (Exception ignored) {
            return "Unknown Land";
        }
    }

    @Nullable
    public String getNationName(Player player) {
        if (!isAvailable()) return null;
        try {
            LandPlayer landPlayer = landsApi.getLandPlayer(player.getUniqueId());
            if (landPlayer == null) return null;
            Land edit = landPlayer.getEditLand(false);
            if (edit != null && edit.getNation() != null) return edit.getNation().getName();
        } catch (Exception ignored) {
        }
        return null;
    }

    public boolean canManagePorts(Player player, Location location) {
        if (!isAvailable()) return false;
        try {
            Land land = landsApi.getLandByUnloadedChunk(location.getWorld(), location.getChunk().getX(), location.getChunk().getZ());
            if (land == null) return false;
            UUID uuid = player.getUniqueId();
            return land.getOwnerUID() != null && land.getOwnerUID().equals(uuid) || player.hasPermission("landsnationboost.port.admin");
        } catch (Exception ignored) {
            return false;
        }
    }

    public boolean isNationAlly(String nationA, String nationB) {
        if (nationA == null || nationB == null) return false;
        if (nationA.equalsIgnoreCase(nationB)) return true;
        return false;
    }

    private void cache(UUID playerId, @Nullable String nationId, long now) {
        nationByPlayerCache.put(playerId, new CachedNation(nationId, now + LOOKUP_CACHE_TTL_MS));
    }

    private record CachedNation(@Nullable String nationId, long expiresAt) {
    }
}
