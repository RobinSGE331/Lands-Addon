package de.robin.landsboost.port.gui;

import de.robin.landsboost.port.model.Port;
import org.bukkit.entity.Player;

public class PortTravelConfirmGui {
    private final PortGui portGui;

    public PortTravelConfirmGui(PortGui portGui) {
        this.portGui = portGui;
    }

    public void open(Player player, Port port) {
        portGui.openConfirm(player, port);
    }
}
