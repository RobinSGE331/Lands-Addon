package de.robin.landsboost.port.listener;

import de.robin.landsboost.port.gui.PortGui;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class PortGuiListener implements Listener {
    private final PortGui gui;

    public PortGuiListener(PortGui gui) {
        this.gui = gui;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null) return;
        if (gui.handleClick(player, event.getInventory(), event.getRawSlot())) {
            event.setCancelled(true);
        }
    }
}
