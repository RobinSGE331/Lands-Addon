package de.robin.landsboost.diplomacy.listener;

import de.robin.landsboost.diplomacy.command.DiplomacyCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class LandsDiplomacyBridgeListener implements Listener {
    private final DiplomacyCommand command;

    public LandsDiplomacyBridgeListener(DiplomacyCommand command) {
        this.command = command;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage();
        String lower = message.toLowerCase();
        if (lower.startsWith("/lands diplomacy")) {
            event.setCancelled(true);
            command.openGui(event.getPlayer());
            return;
        }
        if (lower.startsWith("/lands ally")) {
            event.setCancelled(true);
            Player player = event.getPlayer();
            String[] split = message.substring(1).split("\\s+");
            String[] args = new String[Math.max(0, split.length - 2)];
            if (split.length > 2) System.arraycopy(split, 2, args, 0, split.length - 2);
            command.handleAlly(player, args);
            return;
        }
        if (lower.startsWith("/lands war")) {
            event.setCancelled(true);
            Player player = event.getPlayer();
            String[] split = message.substring(1).split("\\s+");
            String[] args = new String[Math.max(0, split.length - 2)];
            if (split.length > 2) System.arraycopy(split, 2, args, 0, split.length - 2);
            command.handleWar(player, args);
        }
    }
}
