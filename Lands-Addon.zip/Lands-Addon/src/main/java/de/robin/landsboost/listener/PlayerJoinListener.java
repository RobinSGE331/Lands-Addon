package de.robin.landsboost.listener;

import de.robin.landsboost.manager.BoostActivationManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerJoinListener implements Listener {

    private final BoostActivationManager activationManager;

    public PlayerJoinListener(BoostActivationManager activationManager) {
        this.activationManager = activationManager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        activationManager.applyActiveBoostsForPlayer(event.getPlayer());
    }
}
