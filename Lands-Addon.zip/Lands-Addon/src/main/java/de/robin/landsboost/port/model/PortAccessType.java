package de.robin.landsboost.port.model;

public enum PortAccessType {
    PRIVATE,
    NATION,
    ALLY,
    PUBLIC,
    ADMIN_ONLY;

    public static PortAccessType fromString(String value) {
        for (PortAccessType type : values()) {
            if (type.name().equalsIgnoreCase(value)) return type;
        }
        return NATION;
    }
}
