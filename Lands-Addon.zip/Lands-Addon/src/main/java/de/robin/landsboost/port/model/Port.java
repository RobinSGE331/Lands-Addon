package de.robin.landsboost.port.model;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.UUID;

public class Port {
    private final UUID id;
    private String name;
    private String world;
    private double x;
    private double y;
    private double z;
    private float yaw;
    private float pitch;
    private String ownerLandId;
    private String ownerLandName;
    private String ownerNationId;
    private String ownerNationName;
    private PortAccessType accessType;
    private boolean enabled;
    private double travelCost;
    private UUID createdBy;
    private long createdAt;

    public Port(UUID id) {
        this.id = id;
    }

    public UUID getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getWorld() { return world; }
    public void setWorld(String world) { this.world = world; }
    public double getX() { return x; }
    public void setX(double x) { this.x = x; }
    public double getY() { return y; }
    public void setY(double y) { this.y = y; }
    public double getZ() { return z; }
    public void setZ(double z) { this.z = z; }
    public float getYaw() { return yaw; }
    public void setYaw(float yaw) { this.yaw = yaw; }
    public float getPitch() { return pitch; }
    public void setPitch(float pitch) { this.pitch = pitch; }
    public String getOwnerLandId() { return ownerLandId; }
    public void setOwnerLandId(String ownerLandId) { this.ownerLandId = ownerLandId; }
    public String getOwnerLandName() { return ownerLandName; }
    public void setOwnerLandName(String ownerLandName) { this.ownerLandName = ownerLandName; }
    public String getOwnerNationId() { return ownerNationId; }
    public void setOwnerNationId(String ownerNationId) { this.ownerNationId = ownerNationId; }
    public String getOwnerNationName() { return ownerNationName; }
    public void setOwnerNationName(String ownerNationName) { this.ownerNationName = ownerNationName; }
    public PortAccessType getAccessType() { return accessType; }
    public void setAccessType(PortAccessType accessType) { this.accessType = accessType; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public double getTravelCost() { return travelCost; }
    public void setTravelCost(double travelCost) { this.travelCost = travelCost; }
    public UUID getCreatedBy() { return createdBy; }
    public void setCreatedBy(UUID createdBy) { this.createdBy = createdBy; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    public Location toLocation() {
        World w = Bukkit.getWorld(world);
        return w == null ? null : new Location(w, x, y, z, yaw, pitch);
    }
}
