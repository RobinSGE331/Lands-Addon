package de.robin.landsboost.port.manager;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class EconomyManager {
    private Economy economy;

    public EconomyManager(JavaPlugin plugin) {
        RegisteredServiceProvider<Economy> provider = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (provider != null) {
            this.economy = provider.getProvider();
        }
    }

    public boolean isAvailable() {
        return economy != null;
    }

    public boolean charge(Player player, double amount) {
        if (amount <= 0.0) return true;
        if (!isAvailable()) return true;
        if (!economy.has(player, amount)) return false;
        return economy.withdrawPlayer(player, amount).transactionSuccess();
    }
}
