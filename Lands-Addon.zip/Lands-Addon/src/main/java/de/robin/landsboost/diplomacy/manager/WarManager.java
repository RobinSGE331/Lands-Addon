package de.robin.landsboost.diplomacy.manager;

import de.robin.landsboost.diplomacy.model.DiplomacyRelation;

public class WarManager {
    private final DiplomacyManager diplomacyManager;

    public WarManager(DiplomacyManager diplomacyManager) {
        this.diplomacyManager = diplomacyManager;
    }

    public void request(String fromNation, String toNation) {
        diplomacyManager.createRequest(fromNation, toNation, DiplomacyRelation.ENEMY);
    }

    public boolean accept(String fromNation, String toNation) {
        return diplomacyManager.acceptRequest(fromNation, toNation, DiplomacyRelation.ENEMY);
    }

    public boolean deny(String fromNation, String toNation) {
        return diplomacyManager.denyRequest(fromNation, toNation, DiplomacyRelation.ENEMY);
    }

    public void end(String nationA, String nationB) {
        diplomacyManager.clearRelation(nationA, nationB);
    }
}
