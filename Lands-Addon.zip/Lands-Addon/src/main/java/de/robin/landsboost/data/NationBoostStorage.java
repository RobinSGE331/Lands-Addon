package de.robin.landsboost.data;

import de.robin.landsboost.LandsNationBoostPlugin;
import de.robin.landsboost.model.ActiveBoost;
import de.robin.landsboost.model.NationBoostData;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class NationBoostStorage {

    private final LandsNationBoostPlugin plugin;
    private final File file;
    private final FileConfiguration yaml;
    private final ConcurrentHashMap<String, NationBoostData> nationData = new ConcurrentHashMap<>();
    private volatile boolean dirty = false;
    private volatile int saveTaskId = -1;

    public NationBoostStorage(LandsNationBoostPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "nations.yml");
        this.yaml = YamlConfiguration.loadConfiguration(file);
        load();
    }

    public NationBoostData getOrCreate(String nationId) {
        return nationData.computeIfAbsent(nationId, ignored -> new NationBoostData());
    }

    public Map<String, NationBoostData> snapshot() {
        return Map.copyOf(nationData);
    }

    public void markDirty(int asyncSaveDelayTicks) {
        dirty = true;
        if (saveTaskId != -1) return;
        saveTaskId = Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, this::saveIfDirty, asyncSaveDelayTicks).getTaskId();
    }

    public synchronized void saveNow() {
        writeToYaml();
        try {
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save nations.yml: " + e.getMessage());
        } finally {
            dirty = false;
            saveTaskId = -1;
        }
    }

    private synchronized void saveIfDirty() {
        if (!dirty) {
            saveTaskId = -1;
            return;
        }
        saveNow();
    }

    private void load() {
        ConfigurationSection nations = yaml.getConfigurationSection("nations");
        if (nations == null) return;

        for (String nationId : nations.getKeys(false)) {
            NationBoostData data = new NationBoostData();
            ConfigurationSection nation = nations.getConfigurationSection(nationId);
            if (nation == null) continue;

            ConfigurationSection inventory = nation.getConfigurationSection("inventory");
            if (inventory != null) {
                for (String boostId : inventory.getKeys(false)) {
                    data.addAmount(boostId, Math.max(0, inventory.getInt(boostId, 0)));
                }
            }

            ConfigurationSection active = nation.getConfigurationSection("active");
            if (active != null) {
                for (String boostId : active.getKeys(false)) {
                    ConfigurationSection activeEntry = active.getConfigurationSection(boostId);
                    if (activeEntry == null) continue;
                    long expiresAt = activeEntry.getLong("expires-at", 0L);
                    long startedAt = activeEntry.getLong("started-at", 0L);
                    if (expiresAt > 0L) {
                        data.setActiveBoost(new ActiveBoost(boostId, startedAt, expiresAt));
                    }
                }
            }

            ConfigurationSection cooldowns = nation.getConfigurationSection("cooldowns");
            if (cooldowns != null) {
                for (String boostId : cooldowns.getKeys(false)) {
                    data.setCooldown(boostId, cooldowns.getLong(boostId, 0L));
                }
            }

            nationData.put(nationId, data);
        }
    }

    private void writeToYaml() {
        yaml.set("nations", null);
        for (Map.Entry<String, NationBoostData> entry : nationData.entrySet()) {
            String base = "nations." + entry.getKey();
            NationBoostData data = entry.getValue();

            for (Map.Entry<String, Integer> inv : data.getInventory().entrySet()) {
                yaml.set(base + ".inventory." + inv.getKey(), inv.getValue());
            }
            for (Map.Entry<String, ActiveBoost> active : data.getActiveBoosts().entrySet()) {
                yaml.set(base + ".active." + active.getKey() + ".started-at", active.getValue().startedAt());
                yaml.set(base + ".active." + active.getKey() + ".expires-at", active.getValue().expiresAt());
            }
            for (Map.Entry<String, Long> cd : data.getCooldowns().entrySet()) {
                yaml.set(base + ".cooldowns." + cd.getKey(), cd.getValue());
            }
        }
    }
}
