package de.robin.landsboost.manager;

import de.robin.landsboost.LandsNationBoostPlugin;
import de.robin.landsboost.config.BoostConfigManager;
import de.robin.landsboost.hook.LandsHook;
import de.robin.landsboost.model.ActiveBoost;
import de.robin.landsboost.model.BoostDefinition;
import de.robin.landsboost.model.NationBoostData;
import de.robin.landsboost.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class BoostActivationManager {

    private final LandsNationBoostPlugin plugin;
    private final LandsHook landsHook;
    private final BoostConfigManager config;
    private final BoostInventoryManager inventoryManager;
    private int taskId = -1;

    public BoostActivationManager(LandsNationBoostPlugin plugin, LandsHook landsHook, BoostConfigManager config, BoostInventoryManager inventoryManager) {
        this.plugin = plugin;
        this.landsHook = landsHook;
        this.config = config;
        this.inventoryManager = inventoryManager;
    }

    public ActivateResult activate(String nationId, Player actor, String boostId) {
        Optional<BoostDefinition> optional = config.findBoost(boostId);
        if (optional.isEmpty()) return ActivateResult.NOT_FOUND;
        BoostDefinition boost = optional.get();

        if (!boost.permission().isBlank() && !actor.hasPermission(boost.permission())) {
            return ActivateResult.NO_PERMISSION;
        }

        NationBoostData data = inventoryManager.getData(nationId);
        long now = System.currentTimeMillis();

        Long cooldownUntil = data.getCooldowns().get(boost.id());
        boolean bypassCooldown = actor.hasPermission("landsboost.bypasscooldown") || actor.hasPermission("landsboost.admin");
        if (!bypassCooldown && cooldownUntil != null && cooldownUntil > now) return ActivateResult.COOLDOWN;

        boolean blocksByGlobal = !config.allowMultipleGlobal() && data.hasAnyActive(now);
        boolean blocksByBoost = !boost.allowStackWithOtherActive() && data.hasAnyActive(now);
        if (blocksByGlobal || blocksByBoost) return ActivateResult.OTHER_ACTIVE;

        if (!inventoryManager.consumeBoost(nationId, boost.id(), config.asyncSaveDelayTicks())) {
            return ActivateResult.NOT_ENOUGH;
        }

        long expiresAt = now + boost.durationSeconds() * 1000L;
        data.setActiveBoost(new ActiveBoost(boost.id(), now, expiresAt));
        if (boost.cooldownSeconds() > 0) {
            data.setCooldown(boost.id(), now + boost.cooldownSeconds() * 1000L);
        }
        applyBoostToNationMembers(nationId, boost);
        return ActivateResult.OK;
    }

    public void applyActiveBoostsForPlayer(Player player) {
        String nationId = landsHook.getNationId(player);
        if (nationId == null) return;
        NationBoostData data = inventoryManager.getData(nationId);
        long now = System.currentTimeMillis();
        for (ActiveBoost active : data.getActiveBoosts().values()) {
            if (!active.isActive(now)) continue;
            config.findBoost(active.boostId()).ifPresent(def -> applyEffect(player, def));
        }
    }

    public void cleanupExpiredBoosts() {
        long now = System.currentTimeMillis();
        for (Map.Entry<String, NationBoostData> entry : inventoryManager.getAllData().entrySet()) {
            entry.getValue().removeExpiredActive(now);
        }
    }

    public void startEffectTask() {
        // Lightweight refresh loop: short potion effects are re-applied every 5 seconds.
        // This avoids per-tick work while keeping effects stable for all online nation members.
        this.taskId = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long now = System.currentTimeMillis();
            for (Player online : Bukkit.getOnlinePlayers()) {
                String nationId = landsHook.getNationId(online);
                if (nationId == null) continue;
                NationBoostData data = inventoryManager.getData(nationId);
                data.removeExpiredActive(now);
                for (ActiveBoost active : data.getActiveBoosts().values()) {
                    config.findBoost(active.boostId()).ifPresent(def -> applyEffect(online, def));
                }
            }
        }, 20L, 100L).getTaskId();
    }

    public void shutdown() {
        if (taskId != -1) {
            Bukkit.getScheduler().cancelTask(taskId);
        }
    }

    private void applyBoostToNationMembers(String nationId, BoostDefinition boost) {
        Set<Player> members = landsHook.getOnlineNationMembers(nationId);
        for (Player member : members) {
            applyEffect(member, boost);
            announceBoost(member, boost);
        }
    }

    private void applyEffect(Player player, BoostDefinition boost) {
        int durationTicks = 20 * 8;
        PotionEffect effect = new PotionEffect(boost.effectType(), durationTicks, boost.amplifier(), true, false, true);
        player.addPotionEffect(effect, true);
    }

    private void announceBoost(Player player, BoostDefinition boost) {
        if (!config.boostAnnouncementEnabled()) return;
        String boostName = ColorUtil.colorize(boost.displayName());
        if (config.boostTitleEnabled()) {
            String title = ColorUtil.colorize(config.boostTitleText().replace("%boost_name%", boostName));
            String subtitle = ColorUtil.colorize(config.boostSubtitleText().replace("%boost_name%", boostName));
            player.sendTitle(title, subtitle, 10, 50, 10);
        }
        if (config.boostActionbarEnabled()) {
            player.sendActionBar(ColorUtil.colorize(config.boostActionbarText().replace("%boost_name%", boostName)));
        }
        if (config.boostSoundEnabled()) {
            player.playSound(player.getLocation(), config.boostSound(), 1f, 1f);
        }
    }

    public enum ActivateResult {
        OK, NOT_FOUND, NO_PERMISSION, COOLDOWN, OTHER_ACTIVE, NOT_ENOUGH
    }
}
