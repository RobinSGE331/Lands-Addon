package de.robin.landsboost.port.manager;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

import java.util.Set;

public class PortSafeLocationFinder {
    private static final Set<Material> UNSAFE = Set.of(Material.LAVA, Material.FIRE, Material.CACTUS, Material.MAGMA_BLOCK);

    public Location findSafe(Location base, int radius) {
        if (base == null || base.getWorld() == null) return null;
        if (isSafe(base)) return base.clone().add(0.5, 0, 0.5);
        World w = base.getWorld();
        int bx = base.getBlockX();
        int by = Math.max(1, base.getBlockY());
        int bz = base.getBlockZ();
        for (int r = 1; r <= radius; r++) {
            for (int x = -r; x <= r; x++) {
                for (int z = -r; z <= r; z++) {
                    Location test = new Location(w, bx + x, by, bz + z, base.getYaw(), base.getPitch());
                    if (isSafe(test)) return test.add(0.5, 0, 0.5);
                }
            }
        }
        return null;
    }

    private boolean isSafe(Location location) {
        Block feet = location.getBlock();
        Block head = feet.getRelative(0, 1, 0);
        Block ground = feet.getRelative(0, -1, 0);
        if (ground.getType().isAir()) return false;
        if (!feet.getType().isAir() || !head.getType().isAir()) return false;
        return !UNSAFE.contains(ground.getType()) && ground.getY() > 0;
    }
}
