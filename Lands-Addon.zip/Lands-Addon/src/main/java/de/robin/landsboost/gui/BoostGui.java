package de.robin.landsboost.gui;

import de.robin.landsboost.LandsNationBoostPlugin;
import de.robin.landsboost.config.BoostConfigManager;
import de.robin.landsboost.manager.BoostActivationManager;
import de.robin.landsboost.manager.BoostInventoryManager;
import de.robin.landsboost.model.ActiveBoost;
import de.robin.landsboost.model.BoostDefinition;
import de.robin.landsboost.model.NationBoostData;
import de.robin.landsboost.util.ColorUtil;
import de.robin.landsboost.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

public class BoostGui {

    private final LandsNationBoostPlugin plugin;
    private final BoostConfigManager config;
    private final BoostInventoryManager inventoryManager;
    private final BoostActivationManager activationManager;
    private final Map<Inventory, Map<Integer, String>> slotMap = new WeakHashMap<>();

    public BoostGui(LandsNationBoostPlugin plugin, BoostConfigManager config, BoostInventoryManager inventoryManager, BoostActivationManager activationManager) {
        this.plugin = plugin;
        this.config = config;
        this.inventoryManager = inventoryManager;
        this.activationManager = activationManager;
    }

    public void open(Player player, String nationId) {
        Inventory inventory = Bukkit.createInventory(new BoostInventoryHolder(nationId), config.guiSize(), ColorUtil.colorize(config.guiTitle()));
        NationBoostData data = inventoryManager.getData(nationId);
        Map<Integer, String> slotToBoost = new HashMap<>();
        int slot = 0;
        long now = System.currentTimeMillis();

        for (BoostDefinition boost : config.getBoosts()) {
            if (slot >= inventory.getSize()) break;
            int amount = data.getAmount(boost.id());
            ActiveBoost active = data.getActiveBoosts().get(boost.id());
            long remaining = active != null ? active.remainingSeconds(now) : 0L;

            ItemStack item = new ItemStack(boost.material() == null ? Material.PAPER : boost.material());
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ColorUtil.colorize(boost.displayName()));
                List<String> lore = new ArrayList<>(ColorUtil.colorize(boost.lore()));
                lore.add(" ");
                lore.add(ColorUtil.colorize("&7Effect: &f" + boost.effectType().getName()));
                lore.add(ColorUtil.colorize("&7Duration: &f" + TimeUtil.formatSeconds(boost.durationSeconds())));
                lore.add(ColorUtil.colorize("&7In Nation Storage: &f" + amount));
                lore.add(ColorUtil.colorize("&7Active: " + (remaining > 0 ? "&aYes" : "&cNo")));
                if (remaining > 0) {
                    lore.add(ColorUtil.colorize("&7Remaining: &f" + TimeUtil.formatSeconds(remaining)));
                }
                lore.add(ColorUtil.colorize("&eClick to activate"));
                meta.setLore(lore);
                meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
                item.setItemMeta(meta);
            }
            inventory.setItem(slot, item);
            slotToBoost.put(slot, boost.id());
            slot++;
        }
        slotMap.put(inventory, slotToBoost);

        player.openInventory(inventory);
    }

    public boolean handleClick(Player player, Inventory clickedInventory, int rawSlot) {
        if (!(clickedInventory.getHolder() instanceof BoostInventoryHolder holder)) return false;
        String boostId = slotMap.getOrDefault(clickedInventory, Map.of()).get(rawSlot);
        if (boostId == null) return true;

        BoostActivationManager.ActivateResult result = activationManager.activate(holder.nationId(), player, boostId);
        switch (result) {
            case OK -> player.sendMessage(ColorUtil.colorize(config.prefix() + config.msg("activated")
                    .replace("%boost%", boostId)
                    .replace("%duration%", TimeUtil.formatSeconds(config.findBoost(boostId).map(BoostDefinition::durationSeconds).orElse(0)))));
            case NOT_FOUND -> player.sendMessage(ColorUtil.colorize(config.prefix() + config.msg("boost-not-found").replace("%boost%", boostId)));
            case NO_PERMISSION -> player.sendMessage(ColorUtil.colorize(config.prefix() + config.msg("no-permission")));
            case COOLDOWN -> player.sendMessage(ColorUtil.colorize(config.prefix() + config.msg("cooldown").replace("%time%", "active")));
            case OTHER_ACTIVE -> player.sendMessage(ColorUtil.colorize(config.prefix() + config.msg("blocked-by-active")));
            case NOT_ENOUGH -> player.sendMessage(ColorUtil.colorize(config.prefix() + config.msg("not-enough")));
        }
        open(player, holder.nationId());
        return true;
    }

    public record BoostInventoryHolder(String nationId) implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}
