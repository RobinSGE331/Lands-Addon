package de.robin.landsboost.model;

import org.bukkit.Material;
import org.bukkit.potion.PotionEffectType;

import java.util.List;

public record BoostDefinition(
        String id,
        String displayName,
        Material material,
        List<String> lore,
        PotionEffectType effectType,
        int amplifier,
        int durationSeconds,
        boolean allowStackWithOtherActive,
        int cooldownSeconds,
        String permission
) {
}
