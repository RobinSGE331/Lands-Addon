package de.robin.landsboost;

import de.robin.landsboost.command.NationBoostCommandExecutor;
import de.robin.landsboost.config.BoostConfigManager;
import de.robin.landsboost.data.NationBoostStorage;
import de.robin.landsboost.gui.BoostGui;
import de.robin.landsboost.hook.LandsHook;
import de.robin.landsboost.listener.BoostGuiListener;
import de.robin.landsboost.listener.LandsCommandBridgeListener;
import de.robin.landsboost.listener.PlayerJoinListener;
import de.robin.landsboost.manager.BoostActivationManager;
import de.robin.landsboost.manager.BoostInventoryManager;
import de.robin.landsboost.diplomacy.command.DiplomacyCommand;
import de.robin.landsboost.diplomacy.gui.DiplomacyGui;
import de.robin.landsboost.diplomacy.listener.LandsDiplomacyBridgeListener;
import de.robin.landsboost.diplomacy.manager.AllianceManager;
import de.robin.landsboost.diplomacy.manager.DiplomacyManager;
import de.robin.landsboost.diplomacy.manager.WarManager;
import de.robin.landsboost.diplomacy.placeholder.RelationPlaceholder;
import de.robin.landsboost.diplomacy.storage.DiplomacyStorage;
import de.robin.landsboost.port.command.PortCommand;
import de.robin.landsboost.port.command.PortFallbackExecutor;
import de.robin.landsboost.port.gui.PortGui;
import de.robin.landsboost.port.listener.LandsPortCommandBridgeListener;
import de.robin.landsboost.port.listener.PortGuiListener;
import de.robin.landsboost.port.listener.PortTravelListener;
import de.robin.landsboost.port.manager.*;
import de.robin.landsboost.port.storage.PortStorage;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class LandsNationBoostPlugin extends JavaPlugin {

    private LandsHook landsHook;
    private BoostConfigManager boostConfigManager;
    private NationBoostStorage nationBoostStorage;
    private BoostInventoryManager boostInventoryManager;
    private BoostActivationManager boostActivationManager;
    private BoostGui boostGui;
    private NationBoostCommandExecutor commandExecutor;
    private PortStorage portStorage;
    private PortTravelManager portTravelManager;
    private DiplomacyManager diplomacyManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("nations.yml", false);
        saveResource("ports.yml", false);
        saveResource("diplomacy.yml", false);

        this.landsHook = new LandsHook(this);
        this.boostConfigManager = new BoostConfigManager(this);
        this.nationBoostStorage = new NationBoostStorage(this);
        this.boostInventoryManager = new BoostInventoryManager(nationBoostStorage);
        this.boostActivationManager = new BoostActivationManager(this, landsHook, boostConfigManager, boostInventoryManager);
        this.boostGui = new BoostGui(this, boostConfigManager, boostInventoryManager, boostActivationManager);
        this.commandExecutor = new NationBoostCommandExecutor(this, landsHook, boostConfigManager, boostInventoryManager, boostGui);
        DiplomacyStorage diplomacyStorage = new DiplomacyStorage(this);
        this.diplomacyManager = new DiplomacyManager(diplomacyStorage);
        AllianceManager allianceManager = new AllianceManager(diplomacyManager);
        WarManager warManager = new WarManager(diplomacyManager);
        DiplomacyGui diplomacyGui = new DiplomacyGui(diplomacyManager, landsHook);
        DiplomacyCommand diplomacyCommand = new DiplomacyCommand(landsHook, diplomacyManager, allianceManager, warManager, diplomacyGui);
        PortConfig portConfig = new PortConfig(this);
        EconomyManager economyManager = new EconomyManager(this);
        this.portStorage = new PortStorage(this);
        PortManager portManager = new PortManager(portStorage, portConfig, landsHook, diplomacyManager);
        PortPermissionManager portPermissionManager = new PortPermissionManager();
        PortCreationValidator portCreationValidator = new PortCreationValidator(landsHook, portConfig);
        PortSafeLocationFinder safeLocationFinder = new PortSafeLocationFinder();
        this.portTravelManager = new PortTravelManager(this, portConfig, economyManager, safeLocationFinder);
        PortGui portGui = new PortGui(portConfig, portManager, portTravelManager);
        PortCommand portCommand = new PortCommand(portConfig, portManager, portCreationValidator, portTravelManager, portGui, portPermissionManager, economyManager);
        PluginCommand portFallback = getCommand("nationport");
        if (portFallback != null) {
            portFallback.setExecutor(new PortFallbackExecutor(portCommand, false));
        }
        PluginCommand portAdminFallback = getCommand("nationportadmin");
        if (portAdminFallback != null) {
            portAdminFallback.setExecutor(new PortFallbackExecutor(portCommand, true));
        }

        PluginCommand fallbackCommand = getCommand("nationboost");
        if (fallbackCommand != null) {
            fallbackCommand.setExecutor(commandExecutor);
            fallbackCommand.setTabCompleter(commandExecutor);
        }

        Bukkit.getPluginManager().registerEvents(new BoostGuiListener(boostGui), this);
        Bukkit.getPluginManager().registerEvents(new LandsCommandBridgeListener(commandExecutor), this);
        Bukkit.getPluginManager().registerEvents(new PlayerJoinListener(boostActivationManager), this);
        Bukkit.getPluginManager().registerEvents(new LandsPortCommandBridgeListener(portCommand), this);
        Bukkit.getPluginManager().registerEvents(new PortGuiListener(portGui), this);
        Bukkit.getPluginManager().registerEvents(new PortTravelListener(portTravelManager), this);
        Bukkit.getPluginManager().registerEvents(new LandsDiplomacyBridgeListener(diplomacyCommand), this);

        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new RelationPlaceholder(landsHook, diplomacyManager).register();
        }

        boostActivationManager.startEffectTask();
        getLogger().info("LandsNationBoost enabled.");
    }

    @Override
    public void onDisable() {
        if (boostActivationManager != null) {
            boostActivationManager.shutdown();
        }
        if (nationBoostStorage != null) {
            nationBoostStorage.saveNow();
        }
        if (portStorage != null) {
            portStorage.saveNow();
        }
        if (portTravelManager != null) {
            portTravelManager.shutdown();
        }
        if (diplomacyManager != null) {
            diplomacyManager.shutdown();
        }
    }

    public void reloadPlugin() {
        reloadConfig();
        boostConfigManager.reload();
        nationBoostStorage.saveNow();
        boostActivationManager.cleanupExpiredBoosts();
    }
}
