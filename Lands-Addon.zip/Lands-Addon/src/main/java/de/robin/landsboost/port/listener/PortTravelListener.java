package de.robin.landsboost.port.listener;

import de.robin.landsboost.port.manager.PortTravelManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public class PortTravelListener implements Listener {
    private final PortTravelManager travelManager;

    public PortTravelListener(PortTravelManager travelManager) {
        this.travelManager = travelManager;
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        travelManager.cancelIfMoved(event.getPlayer(), event.getFrom(), event.getTo());
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player) {
            travelManager.cancelIfDamage(player);
        }
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent event) {
        travelManager.cancelIfTeleport(event.getPlayer());
    }
}
