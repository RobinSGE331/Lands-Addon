package de.robin.landsboost.model;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class NationBoostData {
    private final ConcurrentHashMap<String, Integer> inventory = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, ActiveBoost> activeBoosts = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Long> cooldowns = new ConcurrentHashMap<>();

    public Map<String, Integer> getInventory() {
        return Collections.unmodifiableMap(inventory);
    }

    public Map<String, ActiveBoost> getActiveBoosts() {
        return Collections.unmodifiableMap(activeBoosts);
    }

    public Map<String, Long> getCooldowns() {
        return Collections.unmodifiableMap(cooldowns);
    }

    public int getAmount(String boostId) {
        return inventory.getOrDefault(boostId, 0);
    }

    public void addAmount(String boostId, int amount) {
        inventory.compute(boostId, (id, old) -> {
            int current = old == null ? 0 : old;
            int next = current + amount;
            return next <= 0 ? null : next;
        });
    }

    public void setActiveBoost(ActiveBoost boost) {
        activeBoosts.put(boost.boostId(), boost);
    }

    public void removeActiveBoost(String boostId) {
        activeBoosts.remove(boostId);
    }

    public boolean hasAnyActive(long now) {
        return activeBoosts.values().stream().anyMatch(active -> active.isActive(now));
    }

    public void setCooldown(String boostId, long until) {
        cooldowns.put(boostId, until);
    }

    public void removeExpiredActive(long now) {
        activeBoosts.values().removeIf(active -> !active.isActive(now));
    }
}
