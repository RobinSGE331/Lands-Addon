package de.robin.landsboost.port.gui;

import de.robin.landsboost.port.manager.PortManager;
import de.robin.landsboost.port.model.Port;
import de.robin.landsboost.util.ColorUtil;
import org.bukkit.entity.Player;

public class AdminPortGui {
    private final PortManager portManager;

    public AdminPortGui(PortManager portManager) {
        this.portManager = portManager;
    }

    public void open(Player player) {
        player.sendMessage(ColorUtil.colorize("&8----- &bAdmin Ports &8-----"));
        for (Port port : portManager.all()) {
            player.sendMessage(ColorUtil.colorize("&8- &f" + port.getName() + " &7[" + (port.isEnabled() ? "ENABLED" : "DISABLED") + "]"));
        }
    }
}
