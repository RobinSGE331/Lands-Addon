package de.robin.landsboost.port.listener;

import de.robin.landsboost.port.command.PortCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class LandsPortCommandBridgeListener implements Listener {
    private final PortCommand portCommand;

    public LandsPortCommandBridgeListener(PortCommand portCommand) {
        this.portCommand = portCommand;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage();
        String lower = message.toLowerCase();
        if (lower.startsWith("/lands portadmin")) {
            event.setCancelled(true);
            Player player = event.getPlayer();
            String[] split = message.substring(1).split("\\s+");
            String[] args = new String[Math.max(0, split.length - 2)];
            if (split.length > 2) System.arraycopy(split, 2, args, 0, split.length - 2);
            portCommand.handleAdmin(player, args);
            return;
        }
        if (!lower.startsWith("/lands port")) return;
        event.setCancelled(true);
        Player player = event.getPlayer();
        String[] split = message.substring(1).split("\\s+");
        String[] args = new String[Math.max(0, split.length - 2)];
        if (split.length > 2) System.arraycopy(split, 2, args, 0, split.length - 2);
        portCommand.handle(player, args);
    }
}
