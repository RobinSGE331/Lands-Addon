package de.robin.landsboost.manager;

import de.robin.landsboost.data.NationBoostStorage;
import de.robin.landsboost.model.NationBoostData;

public class BoostInventoryManager {

    private final NationBoostStorage storage;

    public BoostInventoryManager(NationBoostStorage storage) {
        this.storage = storage;
    }

    public int getAmount(String nationId, String boostId) {
        return storage.getOrCreate(nationId).getAmount(boostId);
    }

    public void addBoost(String nationId, String boostId, int amount, int saveDelayTicks) {
        NationBoostData data = storage.getOrCreate(nationId);
        data.addAmount(boostId, amount);
        storage.markDirty(saveDelayTicks);
    }

    public boolean consumeBoost(String nationId, String boostId, int saveDelayTicks) {
        NationBoostData data = storage.getOrCreate(nationId);
        int current = data.getAmount(boostId);
        if (current <= 0) return false;
        data.addAmount(boostId, -1);
        storage.markDirty(saveDelayTicks);
        return true;
    }

    public NationBoostData getData(String nationId) {
        return storage.getOrCreate(nationId);
    }

    public java.util.Map<String, NationBoostData> getAllData() {
        return storage.snapshot();
    }
}
