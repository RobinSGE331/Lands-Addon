package de.robin.landsboost.port.gui;

import de.robin.landsboost.port.manager.PortConfig;
import de.robin.landsboost.port.manager.PortManager;
import de.robin.landsboost.port.manager.PortTravelManager;
import de.robin.landsboost.port.model.Port;
import de.robin.landsboost.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class PortGui {
    private final PortConfig config;
    private final PortManager portManager;
    private final PortTravelManager travelManager;
    private final Map<Inventory, Map<Integer, UUID>> slotMap = new WeakHashMap<>();

    public PortGui(PortConfig config, PortManager portManager, PortTravelManager travelManager) {
        this.config = config;
        this.portManager = portManager;
        this.travelManager = travelManager;
    }

    public void openMain(Player player) {
        Inventory inv = Bukkit.createInventory(new Holder("main"), 54, ColorUtil.colorize(config.mainTitle()));
        List<Port> ports = portManager.accessibleFor(player);
        Map<Integer, UUID> slots = new HashMap<>();
        int i = 0;
        for (Port port : ports) {
            if (i >= inv.getSize()) break;
            ItemStack item = new ItemStack(port.isEnabled() ? Material.LODESTONE : Material.BARRIER);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ColorUtil.colorize("&e" + port.getName()));
            meta.setLore(List.of(
                    ColorUtil.colorize("&7Land: &f" + port.getOwnerLandName()),
                    ColorUtil.colorize("&7Nation: &f" + port.getOwnerNationName()),
                    ColorUtil.colorize("&7Access: &f" + port.getAccessType().name()),
                    ColorUtil.colorize("&7Cost: &f" + port.getTravelCost()),
                    ColorUtil.colorize("&7Enabled: " + (port.isEnabled() ? "&aYes" : "&cNo")),
                    ColorUtil.colorize("&7Distance: &f" + (int) player.getLocation().distance(Objects.requireNonNullElse(port.toLocation(), player.getLocation())) + "m"),
                    ColorUtil.colorize("&eClick to continue")
            ));
            item.setItemMeta(meta);
            inv.setItem(i, item);
            slots.put(i, port.getId());
            i++;
        }
        slotMap.put(inv, slots);
        player.openInventory(inv);
    }

    public void openConfirm(Player player, Port port) {
        Inventory inv = Bukkit.createInventory(new Holder("confirm"), 27, ColorUtil.colorize(config.confirmTitle()));
        ItemStack confirm = new ItemStack(Material.GREEN_WOOL);
        ItemMeta cm = confirm.getItemMeta();
        cm.setDisplayName(ColorUtil.colorize("&aConfirm travel"));
        cm.setLore(List.of(
                ColorUtil.colorize("&7Destination: &f" + port.getName()),
                ColorUtil.colorize("&7Cost: &f" + port.getTravelCost()),
                ColorUtil.colorize("&7Warmup: &f" + config.warmupSeconds() + "s"),
                ColorUtil.colorize("&7Cooldown: &f" + config.cooldownSeconds() + "s")
        ));
        confirm.setItemMeta(cm);
        inv.setItem(11, confirm);

        ItemStack cancel = new ItemStack(Material.RED_WOOL);
        ItemMeta xm = cancel.getItemMeta();
        xm.setDisplayName(ColorUtil.colorize("&cCancel"));
        cancel.setItemMeta(xm);
        inv.setItem(15, cancel);

        Map<Integer, UUID> slots = new HashMap<>();
        slots.put(11, port.getId());
        slotMap.put(inv, slots);
        player.openInventory(inv);
        player.playSound(player.getLocation(), config.confirmSound(), 1f, 1f);
    }

    public boolean handleClick(Player player, Inventory inv, int slot) {
        if (!(inv.getHolder() instanceof Holder holder)) return false;
        if (holder.type.equals("main")) {
            UUID id = slotMap.getOrDefault(inv, Map.of()).get(slot);
            if (id == null) return true;
            Port port = portManager.all().stream().filter(p -> p.getId().equals(id)).findFirst().orElse(null);
            if (port == null) return true;
            openConfirm(player, port);
            return true;
        }
        if (holder.type.equals("confirm")) {
            if (slot == 15) {
                player.closeInventory();
                return true;
            }
            UUID id = slotMap.getOrDefault(inv, Map.of()).get(11);
            if (slot == 11 && id != null) {
                Port port = portManager.all().stream().filter(p -> p.getId().equals(id)).findFirst().orElse(null);
                if (port != null) {
                    travelManager.startTravel(player, port);
                }
                player.closeInventory();
                return true;
            }
            return true;
        }
        return false;
    }

    private record Holder(String type) implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }
}
