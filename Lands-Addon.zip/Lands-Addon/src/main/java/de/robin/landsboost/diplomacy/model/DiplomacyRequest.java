package de.robin.landsboost.diplomacy.model;

public record DiplomacyRequest(String fromNationId, String toNationId, DiplomacyRelation type, long createdAt) {
    public String key() {
        return fromNationId + "->" + toNationId + ":" + type.name();
    }
}
