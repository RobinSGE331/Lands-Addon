package de.robin.landsboost.port.manager;

import de.robin.landsboost.hook.LandsHook;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class PortCreationValidator {
    private final LandsHook landsHook;
    private final PortConfig config;

    public PortCreationValidator(LandsHook landsHook, PortConfig config) {
        this.landsHook = landsHook;
        this.config = config;
    }

    public String validate(Player player, String name) {
        if (!name.matches("[A-Za-z0-9_-]{3,24}")) return "invalid-name";
        if (config.requireLand() && landsHook.getLandIdAt(player.getLocation()) == null) return "no-land";
        if (!landsHook.canManagePorts(player, player.getLocation())) return "no-permission";
        if (config.requireWaterNearby() && !hasWater(player.getLocation(), config.waterRadius())) return "no-water";
        if (config.reqBlocksEnabled() && !hasRequiredBlocks(player.getLocation(), config.reqBlocksRadius())) return "missing-required-block";
        return null;
    }

    private boolean hasWater(Location center, int radius) {
        for (int x = -radius; x <= radius; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -radius; z <= radius; z++) {
                    if (center.clone().add(x, y, z).getBlock().getType() == Material.WATER) return true;
                }
            }
        }
        return false;
    }

    private boolean hasRequiredBlocks(Location center, int radius) {
        for (Material material : config.reqBlocks()) {
            if (containsBlock(center, radius, material)) return true;
        }
        return false;
    }

    private boolean containsBlock(Location center, int radius, Material material) {
        for (int x = -radius; x <= radius; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -radius; z <= radius; z++) {
                    Block block = center.clone().add(x, y, z).getBlock();
                    if (block.getType() == material) return true;
                }
            }
        }
        return false;
    }
}
