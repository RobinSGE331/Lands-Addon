package de.robin.landsboost.listener;

import de.robin.landsboost.gui.BoostGui;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class BoostGuiListener implements Listener {

    private final BoostGui boostGui;

    public BoostGuiListener(BoostGui boostGui) {
        this.boostGui = boostGui;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null) return;
        boolean handled = boostGui.handleClick(player, event.getInventory(), event.getRawSlot());
        if (handled) {
            event.setCancelled(true);
        }
    }
}
