package de.robin.landsboost.listener;

import de.robin.landsboost.command.NationBoostCommandExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class LandsCommandBridgeListener implements Listener {

    private final NationBoostCommandExecutor executor;

    public LandsCommandBridgeListener(NationBoostCommandExecutor executor) {
        this.executor = executor;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage();
        if (!message.toLowerCase().startsWith("/lands boost")) return;
        event.setCancelled(true);

        Player player = event.getPlayer();
        String[] split = message.substring(1).split("\\s+");
        String[] args = new String[Math.max(0, split.length - 2)];
        if (split.length > 2) {
            System.arraycopy(split, 2, args, 0, split.length - 2);
        }
        executor.handleLandsBoost(player, args);
    }
}
