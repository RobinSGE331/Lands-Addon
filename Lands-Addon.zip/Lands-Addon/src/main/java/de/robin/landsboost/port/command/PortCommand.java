package de.robin.landsboost.port.command;

import de.robin.landsboost.port.gui.PortGui;
import de.robin.landsboost.port.gui.PortInfoGui;
import de.robin.landsboost.port.manager.*;
import de.robin.landsboost.port.model.Port;
import de.robin.landsboost.port.model.PortAccessType;
import de.robin.landsboost.util.ColorUtil;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Locale;

public class PortCommand {
    private final PortConfig config;
    private final PortManager portManager;
    private final PortCreationValidator validator;
    private final PortTravelManager travelManager;
    private final PortGui gui;
    private final PortPermissionManager perms;
    private final EconomyManager economy;
    private final PortInfoGui infoGui = new PortInfoGui();

    public PortCommand(PortConfig config, PortManager portManager, PortCreationValidator validator, PortTravelManager travelManager, PortGui gui, PortPermissionManager perms, EconomyManager economy) {
        this.config = config;
        this.portManager = portManager;
        this.validator = validator;
        this.travelManager = travelManager;
        this.gui = gui;
        this.perms = perms;
        this.economy = economy;
    }

    public void handle(Player player, String[] args) {
        if (!config.enabled()) return;
        if (!perms.has(player, "landsnationboost.port.use")) {
            send(player, "no-permission");
            return;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("menu")) {
            if (!perms.has(player, "landsnationboost.port.menu")) { send(player, "no-permission"); return; }
            gui.openMain(player);
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "list" -> {
                if (!perms.has(player, "landsnationboost.port.list")) { send(player, "no-permission"); return; }
                player.sendMessage(ColorUtil.colorize("&7Accessible ports:"));
                for (Port p : portManager.accessibleFor(player)) player.sendMessage(ColorUtil.colorize("&8- &f" + p.getName()));
            }
            case "create" -> {
                if (!perms.has(player, "landsnationboost.port.create")) { send(player, "no-permission"); return; }
                if (args.length < 2) { player.sendMessage("/lands port create <name>"); return; }
                String name = args[1];
                if (portManager.byName(name) != null) { send(player, "already-exists"); return; }
                String validation = validator.validate(player, name);
                if (validation != null) { send(player, validation); return; }
                if (config.economyEnabled() && economy.isAvailable() && !player.hasPermission("landsnationboost.port.bypass.cost")) {
                    if (!economy.charge(player, config.creationCost())) { send(player, "cannot-pay"); return; }
                }
                Port created = portManager.create(player, name);
                sendRaw(player, config.msg("created").replace("%port%", created.getName()));
            }
            case "delete" -> {
                if (!perms.has(player, "landsnationboost.port.delete")) { send(player, "no-permission"); return; }
                if (args.length < 2) { player.sendMessage("/lands port delete <name>"); return; }
                Port p = portManager.byName(args[1]);
                if (p == null) { send(player, "not-found"); return; }
                if (!portManager.isOwner(player, p) && !player.hasPermission("landsnationboost.port.admin")) { send(player, "no-permission"); return; }
                portManager.delete(p);
                sendRaw(player, config.msg("deleted").replace("%port%", p.getName()));
            }
            case "info" -> {
                if (!perms.has(player, "landsnationboost.port.info")) { send(player, "no-permission"); return; }
                if (args.length < 2) { player.sendMessage("/lands port info <name>"); return; }
                Port p = portManager.byName(args[1]);
                if (p == null) { send(player, "not-found"); return; }
                infoGui.open(player, p);
            }
            case "travel" -> {
                if (!perms.has(player, "landsnationboost.port.travel")) { send(player, "no-permission"); return; }
                if (args.length < 2) { player.sendMessage("/lands port travel <name>"); return; }
                Port p = portManager.byName(args[1]);
                if (p == null) { send(player, "not-found"); return; }
                if (!p.isEnabled()) { send(player, "disabled"); return; }
                if (!portManager.canAccess(player, p)) { send(player, "no-access"); return; }
                String result = travelManager.startTravel(player, p);
                if (result.equals("cooldown")) sendRaw(player, config.msg("cooldown").replace("%time%", travelManager.cooldownText(player)));
                if (result.equals("cannot-pay")) send(player, "cannot-pay");
                if (result.equals("unsafe-destination")) send(player, "unsafe-destination");
            }
            case "rename" -> {
                if (!perms.has(player, "landsnationboost.port.rename")) { send(player, "no-permission"); return; }
                if (args.length < 3) { player.sendMessage("/lands port rename <oldName> <newName>"); return; }
                Port p = portManager.byName(args[1]);
                if (p == null) { send(player, "not-found"); return; }
                if (!portManager.rename(p, args[2])) { send(player, "invalid-name"); return; }
                sendRaw(player, "&aPort renamed to &e" + args[2] + "&a.");
            }
            case "setaccess" -> {
                if (!perms.has(player, "landsnationboost.port.setaccess")) { send(player, "no-permission"); return; }
                if (args.length < 3) { player.sendMessage("/lands port setaccess <name> <private|nation|ally|public>"); return; }
                Port p = portManager.byName(args[1]);
                if (p == null) { send(player, "not-found"); return; }
                if (!portManager.isOwner(player, p) && !player.hasPermission("landsnationboost.port.admin")) { send(player, "no-permission"); return; }
                p.setAccessType(PortAccessType.fromString(args[2]));
                sendRaw(player, "&aPort access updated to &e" + p.getAccessType().name() + "&a.");
            }
            default -> gui.openMain(player);
        }
    }

    public void handleAdmin(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (!perms.has(player, "landsnationboost.port.admin")) {
            send(player, "no-permission");
            return;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            for (Port p : portManager.all()) player.sendMessage(ColorUtil.colorize("&8- &f" + p.getName()));
            return;
        }
        Port p = args.length > 1 ? portManager.byName(args[1]) : null;
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "info" -> {
                if (p == null) { send(player, "not-found"); return; }
                player.performCommand("lands port info " + p.getName());
            }
            case "teleport" -> {
                if (p == null || p.toLocation() == null) { send(player, "not-found"); return; }
                player.teleport(p.toLocation());
            }
            case "delete" -> { if (p == null) send(player, "not-found"); else portManager.delete(p); }
            case "reload" -> player.performCommand("nationboost reload");
            case "forcecreate" -> {
                if (args.length < 2) return;
                if (portManager.byName(args[1]) != null) { send(player, "already-exists"); return; }
                portManager.create(player, args[1]);
            }
            case "enable" -> { if (p != null) p.setEnabled(true); }
            case "disable" -> { if (p != null) p.setEnabled(false); }
            case "setcost" -> { if (p != null && args.length >= 3) p.setTravelCost(Double.parseDouble(args[2])); }
            case "setaccess" -> { if (p != null && args.length >= 3) p.setAccessType(PortAccessType.fromString(args[2])); }
            case "setowner" -> {
                if (p == null || args.length < 4) return;
                if (args[2].equalsIgnoreCase("land")) p.setOwnerLandId(args[3]);
                if (args[2].equalsIgnoreCase("nation")) p.setOwnerNationId(args[3]);
            }
        }
    }

    private void send(Player player, String key) { sendRaw(player, config.msg(key)); }
    private void sendRaw(Player player, String msg) { player.sendMessage(ColorUtil.colorize("&8[&bLandsBoost&8] " + msg)); }
}
