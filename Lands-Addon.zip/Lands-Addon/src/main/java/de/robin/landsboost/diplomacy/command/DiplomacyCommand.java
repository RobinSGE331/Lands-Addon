package de.robin.landsboost.diplomacy.command;

import de.robin.landsboost.diplomacy.gui.DiplomacyGui;
import de.robin.landsboost.diplomacy.manager.AllianceManager;
import de.robin.landsboost.diplomacy.manager.DiplomacyManager;
import de.robin.landsboost.diplomacy.manager.WarManager;
import de.robin.landsboost.hook.LandsHook;
import de.robin.landsboost.util.ColorUtil;
import org.bukkit.entity.Player;

import java.util.Locale;

public class DiplomacyCommand {
    private final LandsHook landsHook;
    private final DiplomacyManager diplomacyManager;
    private final AllianceManager allianceManager;
    private final WarManager warManager;
    private final DiplomacyGui diplomacyGui;

    public DiplomacyCommand(LandsHook landsHook, DiplomacyManager diplomacyManager, AllianceManager allianceManager, WarManager warManager, DiplomacyGui diplomacyGui) {
        this.landsHook = landsHook;
        this.diplomacyManager = diplomacyManager;
        this.allianceManager = allianceManager;
        this.warManager = warManager;
        this.diplomacyGui = diplomacyGui;
    }

    public void handleAlly(Player player, String[] args) {
        if (!player.hasPermission("landsnationboost.diplomacy.use")) return;
        String self = landsHook.getNationId(player);
        if (self == null) return;
        if (args.length == 0) return;
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> { if (player.hasPermission("landsnationboost.ally.list")) player.sendMessage(ColorUtil.colorize("&aAllies: &f" + String.join(", ", diplomacyManager.allies(self)))); }
            case "accept" -> { if (player.hasPermission("landsnationboost.ally.accept") && args.length >= 2) msg(player, allianceManager.accept(args[1], self) ? "&aAlliance accepted." : "&cRequest not found."); }
            case "deny" -> { if (player.hasPermission("landsnationboost.ally.deny") && args.length >= 2) msg(player, allianceManager.deny(args[1], self) ? "&aAlliance denied." : "&cRequest not found."); }
            case "remove" -> { if (player.hasPermission("landsnationboost.ally.remove") && args.length >= 2) { allianceManager.remove(self, args[1]); msg(player, "&aAlliance removed."); } }
            default -> { if (player.hasPermission("landsnationboost.ally")) { allianceManager.request(self, args[0]); msg(player, "&aAlliance request sent to &e" + args[0] + "&a."); } }
        }
    }

    public void handleWar(Player player, String[] args) {
        if (!player.hasPermission("landsnationboost.diplomacy.use")) return;
        String self = landsHook.getNationId(player);
        if (self == null) return;
        if (args.length == 0) return;
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> { if (player.hasPermission("landsnationboost.war.list")) player.sendMessage(ColorUtil.colorize("&cEnemies: &f" + String.join(", ", diplomacyManager.enemies(self)))); }
            case "accept" -> { if (player.hasPermission("landsnationboost.war.accept") && args.length >= 2) msg(player, warManager.accept(args[1], self) ? "&aWar declaration accepted." : "&cRequest not found."); }
            case "deny" -> { if (player.hasPermission("landsnationboost.war.deny") && args.length >= 2) msg(player, warManager.deny(args[1], self) ? "&aWar request denied." : "&cRequest not found."); }
            case "end" -> { if (player.hasPermission("landsnationboost.war.end") && args.length >= 2) { warManager.end(self, args[1]); msg(player, "&aWar ended."); } }
            default -> { if (player.hasPermission("landsnationboost.war")) { warManager.request(self, args[0]); msg(player, "&cWar declaration sent to &e" + args[0] + "&c."); } }
        }
    }

    public void openGui(Player player) {
        diplomacyGui.open(player);
    }

    private void msg(Player player, String text) {
        player.sendMessage(ColorUtil.colorize("&8[&bLandsBoost&8] " + text));
    }
}
