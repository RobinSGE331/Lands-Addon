package de.robin.landsboost.port.manager;

import org.bukkit.entity.Player;

public class PortPermissionManager {
    public boolean has(Player player, String node) {
        return player.hasPermission("landsnationboost.port.admin") || player.hasPermission(node);
    }
}
