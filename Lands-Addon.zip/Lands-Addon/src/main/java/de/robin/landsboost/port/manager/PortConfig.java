package de.robin.landsboost.port.manager;

import de.robin.landsboost.LandsNationBoostPlugin;
import de.robin.landsboost.port.model.PortAccessType;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;

import java.util.List;
import java.util.stream.Collectors;

public class PortConfig {
    private final LandsNationBoostPlugin plugin;

    public PortConfig(LandsNationBoostPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() { return plugin.getConfig().getBoolean("ports.enabled", true); }
    public int maxPortsPerLand() { return plugin.getConfig().getInt("ports.limits.max-ports-per-land", 3); }
    public int maxPortsPerNation() { return plugin.getConfig().getInt("ports.limits.max-ports-per-nation", 10); }
    public boolean economyEnabled() { return plugin.getConfig().getBoolean("ports.economy.enabled", false); }
    public double creationCost() { return plugin.getConfig().getDouble("ports.economy.creation-cost", 500.0); }
    public double defaultTravelCost() { return plugin.getConfig().getDouble("ports.economy.travel-cost", 100.0); }
    public int warmupSeconds() { return plugin.getConfig().getInt("ports.travel.warmup-seconds", 5); }
    public int cooldownSeconds() { return plugin.getConfig().getInt("ports.travel.cooldown-seconds", 60); }
    public boolean cancelOnMove() { return plugin.getConfig().getBoolean("ports.travel.cancel-on-move", true); }
    public boolean cancelOnDamage() { return plugin.getConfig().getBoolean("ports.travel.cancel-on-damage", true); }
    public boolean cancelOnTeleport() { return plugin.getConfig().getBoolean("ports.travel.cancel-on-teleport", true); }
    public int safeRadius() { return plugin.getConfig().getInt("ports.travel.safe-location-search-radius", 5); }
    public boolean requireLand() { return plugin.getConfig().getBoolean("ports.creation.require-land", true); }
    public boolean requireWaterNearby() { return plugin.getConfig().getBoolean("ports.creation.require-water-nearby", true); }
    public int waterRadius() { return plugin.getConfig().getInt("ports.creation.water-check-radius", 8); }
    public boolean reqBlocksEnabled() { return plugin.getConfig().getBoolean("ports.creation.required-nearby-blocks.enabled", false); }
    public int reqBlocksRadius() { return plugin.getConfig().getInt("ports.creation.required-nearby-blocks.radius", 6); }
    public List<Material> reqBlocks() {
        return plugin.getConfig().getStringList("ports.creation.required-nearby-blocks.blocks").stream()
                .map(Material::matchMaterial).filter(m -> m != null).collect(Collectors.toList());
    }
    public PortAccessType defaultAccess() { return PortAccessType.fromString(plugin.getConfig().getString("ports.default-access-type", "NATION")); }
    public String mainTitle() { return plugin.getConfig().getString("ports.gui.main-title", "&8Nation Ports"); }
    public String confirmTitle() { return plugin.getConfig().getString("ports.gui.confirm-title", "&8Confirm Travel"); }
    public String adminTitle() { return plugin.getConfig().getString("ports.gui.admin-title", "&8Admin Ports"); }
    public Sound travelSound() { return Sound.valueOf(plugin.getConfig().getString("ports.effects.travel-sound", "ENTITY_ENDERMAN_TELEPORT")); }
    public Sound confirmSound() { return Sound.valueOf(plugin.getConfig().getString("ports.effects.confirm-sound", "UI_BUTTON_CLICK")); }
    public Particle particle() { return Particle.valueOf(plugin.getConfig().getString("ports.effects.particle", "PORTAL")); }
    public String msg(String key) { return plugin.getConfig().getString("messages.ports." + key, key); }
}
