package de.robin.landsboost.diplomacy.manager;

import de.robin.landsboost.diplomacy.model.DiplomacyRelation;

public class AllianceManager {
    private final DiplomacyManager diplomacyManager;

    public AllianceManager(DiplomacyManager diplomacyManager) {
        this.diplomacyManager = diplomacyManager;
    }

    public void request(String fromNation, String toNation) {
        diplomacyManager.createRequest(fromNation, toNation, DiplomacyRelation.ALLY);
    }

    public boolean accept(String fromNation, String toNation) {
        return diplomacyManager.acceptRequest(fromNation, toNation, DiplomacyRelation.ALLY);
    }

    public boolean deny(String fromNation, String toNation) {
        return diplomacyManager.denyRequest(fromNation, toNation, DiplomacyRelation.ALLY);
    }

    public void remove(String nationA, String nationB) {
        diplomacyManager.clearRelation(nationA, nationB);
    }
}
