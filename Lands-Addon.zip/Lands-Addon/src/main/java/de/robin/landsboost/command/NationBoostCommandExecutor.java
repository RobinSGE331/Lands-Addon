package de.robin.landsboost.command;

import de.robin.landsboost.LandsNationBoostPlugin;
import de.robin.landsboost.config.BoostConfigManager;
import de.robin.landsboost.gui.BoostGui;
import de.robin.landsboost.hook.LandsHook;
import de.robin.landsboost.manager.BoostInventoryManager;
import de.robin.landsboost.model.BoostDefinition;
import de.robin.landsboost.util.ColorUtil;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class NationBoostCommandExecutor implements CommandExecutor, TabCompleter {

    private final LandsNationBoostPlugin plugin;
    private final LandsHook landsHook;
    private final BoostConfigManager config;
    private final BoostInventoryManager inventoryManager;
    private final BoostGui boostGui;

    public NationBoostCommandExecutor(
            LandsNationBoostPlugin plugin,
            LandsHook landsHook,
            BoostConfigManager config,
            BoostInventoryManager inventoryManager,
            BoostGui boostGui
    ) {
        this.plugin = plugin;
        this.landsHook = landsHook;
        this.config = config;
        this.inventoryManager = inventoryManager;
        this.boostGui = boostGui;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players.");
            return true;
        }
        handleLandsBoost(player, args);
        return true;
    }

    public void handleLandsBoost(Player player, String[] args) {
        if (!landsHook.isAvailable()) {
            player.sendMessage(c("lands-not-found"));
            return;
        }
        if (args.length == 0) {
            openGui(player);
            return;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "give" -> handleGive(player, args);
            case "reload" -> handleReload(player);
            case "list" -> handleList(player);
            default -> openGui(player);
        }
    }

    private void openGui(Player player) {
        if (!player.hasPermission("landsboost.use")) {
            player.sendMessage(c("no-permission"));
            return;
        }
        String nationId = landsHook.getNationId(player);
        if (nationId == null) {
            player.sendMessage(c("no-nation"));
            return;
        }
        boostGui.open(player, nationId);
    }

    private void handleGive(Player player, String[] args) {
        if (!hasAdminOr(player, "landsboost.give")) {
            player.sendMessage(c("no-permission"));
            return;
        }
        if (args.length < 4) {
            player.sendMessage(ColorUtil.colorize(config.prefix() + "&cUsage: /lands boost give <player> <boost> <amount>"));
            return;
        }
        OfflinePlayer target = landsHook.findOfflinePlayer(args[1]);
        if (target == null || target.getUniqueId() == null) {
            player.sendMessage(ColorUtil.colorize(config.prefix() + "&cPlayer not found."));
            return;
        }
        BoostDefinition definition = config.findBoost(args[2]).orElse(null);
        if (definition == null) {
            player.sendMessage(c("boost-not-found").replace("%boost%", args[2]));
            return;
        }
        int amount;
        try {
            amount = Math.max(1, Integer.parseInt(args[3]));
        } catch (NumberFormatException ex) {
            player.sendMessage(ColorUtil.colorize(config.prefix() + "&cAmount must be a number."));
            return;
        }
        if (!(target.getPlayer() instanceof Player online)) {
            player.sendMessage(ColorUtil.colorize(config.prefix() + "&cPlayer must be online to resolve their nation."));
            return;
        }
        String nationId = landsHook.getNationId(online);
        if (nationId == null) {
            player.sendMessage(ColorUtil.colorize(config.prefix() + "&cThat player is not in a nation."));
            return;
        }
        inventoryManager.addBoost(nationId, definition.id(), amount, config.asyncSaveDelayTicks());
        player.sendMessage(c("given")
                .replace("%amount%", String.valueOf(amount))
                .replace("%boost%", definition.displayName())
                .replace("%player%", online.getName()));
    }

    private void handleReload(Player player) {
        if (!hasAdminOr(player, "landsboost.reload")) {
            player.sendMessage(c("no-permission"));
            return;
        }
        plugin.reloadPlugin();
        player.sendMessage(c("reload-done"));
    }

    private void handleList(Player player) {
        if (!hasAdminOr(player, "landsboost.list")) {
            player.sendMessage(c("no-permission"));
            return;
        }
        player.sendMessage(c("list-header"));
        for (BoostDefinition boost : config.getBoosts()) {
            player.sendMessage(ColorUtil.colorize("&8- &f" + boost.id() + " &7(" + boost.effectType().getName() + ", " + boost.durationSeconds() + "s)"));
        }
    }

    private boolean hasAdminOr(Player player, String permission) {
        return player.hasPermission("landsboost.admin") || player.hasPermission(permission);
    }

    private String c(String key) {
        return ColorUtil.colorize(config.prefix() + config.msg(key));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("open", "give", "list", "reload");
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return config.getBoosts().stream().map(BoostDefinition::id).collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            return new ArrayList<>();
        }
        return List.of();
    }
}
