package de.robin.landsboost.port.manager;

import de.robin.landsboost.diplomacy.manager.DiplomacyManager;
import de.robin.landsboost.diplomacy.model.DiplomacyRelation;
import de.robin.landsboost.hook.LandsHook;
import de.robin.landsboost.port.model.Port;
import de.robin.landsboost.port.model.PortAccessType;
import de.robin.landsboost.port.storage.PortStorage;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class PortManager {
    private final PortStorage storage;
    private final PortConfig config;
    private final LandsHook landsHook;
    private final DiplomacyManager diplomacyManager;
    private final Map<String, UUID> byName = new ConcurrentHashMap<>();

    public PortManager(PortStorage storage, PortConfig config, LandsHook landsHook, DiplomacyManager diplomacyManager) {
        this.storage = storage;
        this.config = config;
        this.landsHook = landsHook;
        this.diplomacyManager = diplomacyManager;
        rebuildIndex();
    }

    public void rebuildIndex() {
        byName.clear();
        for (Port port : storage.getAll()) byName.put(port.getName().toLowerCase(Locale.ROOT), port.getId());
    }

    public Collection<Port> all() { return storage.getAll(); }

    public Port byName(String name) {
        UUID id = byName.get(name.toLowerCase(Locale.ROOT));
        return id == null ? null : storage.getById(id);
    }

    public Port create(Player creator, String name) {
        Location location = creator.getLocation();
        Port port = new Port(UUID.randomUUID());
        port.setName(name);
        port.setWorld(location.getWorld().getName());
        port.setX(location.getX());
        port.setY(location.getY());
        port.setZ(location.getZ());
        port.setYaw(location.getYaw());
        port.setPitch(location.getPitch());
        port.setOwnerLandId(landsHook.getLandIdAt(location));
        port.setOwnerLandName(landsHook.getLandNameAt(location));
        port.setOwnerNationId(landsHook.getNationId(creator));
        port.setOwnerNationName(landsHook.getNationName(creator));
        port.setAccessType(config.defaultAccess());
        port.setEnabled(true);
        port.setTravelCost(config.defaultTravelCost());
        port.setCreatedBy(creator.getUniqueId());
        port.setCreatedAt(System.currentTimeMillis());
        storage.put(port);
        byName.put(port.getName().toLowerCase(Locale.ROOT), port.getId());
        return port;
    }

    public boolean delete(Port port) {
        if (port == null) return false;
        storage.remove(port.getId());
        byName.remove(port.getName().toLowerCase(Locale.ROOT));
        return true;
    }

    public boolean rename(Port port, String newName) {
        if (port == null || byName.containsKey(newName.toLowerCase(Locale.ROOT))) return false;
        byName.remove(port.getName().toLowerCase(Locale.ROOT));
        port.setName(newName);
        byName.put(newName.toLowerCase(Locale.ROOT), port.getId());
        storage.markDirty();
        return true;
    }

    public boolean canAccess(Player player, Port port) {
        if (player.hasPermission("landsnationboost.port.bypass.access") || player.hasPermission("landsnationboost.port.admin")) return true;
        if (!port.isEnabled()) return false;
        return switch (port.getAccessType()) {
            case PUBLIC -> true;
            case ADMIN_ONLY -> player.hasPermission("landsnationboost.port.admin");
            case PRIVATE -> Objects.equals(port.getOwnerLandId(), landsHook.getLandIdAt(player.getLocation()));
            case NATION -> Objects.equals(port.getOwnerNationId(), landsHook.getNationId(player));
            case ALLY -> diplomacyManager.getRelation(landsHook.getNationId(player), port.getOwnerNationId()) == DiplomacyRelation.ALLY
                    || Objects.equals(port.getOwnerNationId(), landsHook.getNationId(player));
        };
    }

    public boolean isOwner(Player player, Port port) {
        String landId = landsHook.getLandIdAt(player.getLocation());
        String nationId = landsHook.getNationId(player);
        return Objects.equals(landId, port.getOwnerLandId()) || (nationId != null && nationId.equalsIgnoreCase(port.getOwnerNationId()));
    }

    public int countByLand(String landId) {
        if (landId == null) return 0;
        return (int) storage.getAll().stream().filter(p -> landId.equalsIgnoreCase(p.getOwnerLandId())).count();
    }

    public int countByNation(String nationId) {
        if (nationId == null) return 0;
        return (int) storage.getAll().stream().filter(p -> nationId.equalsIgnoreCase(p.getOwnerNationId())).count();
    }

    public List<Port> accessibleFor(Player player) {
        return storage.getAll().stream().filter(port -> canAccess(player, port)).collect(Collectors.toList());
    }
}
