package de.robin.landsboost.model;

public record ActiveBoost(String boostId, long startedAt, long expiresAt) {
    public boolean isActive(long now) {
        return expiresAt > now;
    }

    public long remainingSeconds(long now) {
        return Math.max(0L, (expiresAt - now) / 1000L);
    }
}
