package de.robin.landsboost.port.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PortFallbackExecutor implements CommandExecutor {
    private final PortCommand command;
    private final boolean admin;

    public PortFallbackExecutor(PortCommand command, boolean admin) {
        this.command = command;
        this.admin = admin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;
        if (admin) command.handleAdmin(player, args);
        else command.handle(player, args);
        return true;
    }
}
