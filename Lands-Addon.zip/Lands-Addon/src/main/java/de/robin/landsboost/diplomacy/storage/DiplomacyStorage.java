package de.robin.landsboost.diplomacy.storage;

import de.robin.landsboost.LandsNationBoostPlugin;
import de.robin.landsboost.diplomacy.model.DiplomacyRelation;
import de.robin.landsboost.diplomacy.model.DiplomacyRequest;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class DiplomacyStorage {
    private final LandsNationBoostPlugin plugin;
    private final File file;
    private final FileConfiguration yaml;
    private final Map<String, DiplomacyRelation> relations = new ConcurrentHashMap<>();
    private final Set<DiplomacyRequest> requests = ConcurrentHashMap.newKeySet();
    private volatile boolean dirty;
    private int saveTaskId = -1;

    public DiplomacyStorage(LandsNationBoostPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "diplomacy.yml");
        this.yaml = YamlConfiguration.loadConfiguration(file);
        load();
    }

    public Map<String, DiplomacyRelation> relations() { return relations; }
    public Set<DiplomacyRequest> requests() { return requests; }

    public void markDirty() {
        dirty = true;
        if (saveTaskId != -1) return;
        saveTaskId = Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, this::saveIfDirty, 40L).getTaskId();
    }

    public synchronized void saveNow() {
        yaml.set("relations", null);
        yaml.set("requests", null);
        for (Map.Entry<String, DiplomacyRelation> entry : relations.entrySet()) {
            yaml.set("relations." + entry.getKey(), entry.getValue().name());
        }
        int i = 0;
        for (DiplomacyRequest request : requests) {
            String base = "requests." + i++;
            yaml.set(base + ".from", request.fromNationId());
            yaml.set(base + ".to", request.toNationId());
            yaml.set(base + ".type", request.type().name());
            yaml.set(base + ".created-at", request.createdAt());
        }
        try {
            yaml.save(file);
        } catch (IOException ignored) {
        } finally {
            dirty = false;
            saveTaskId = -1;
        }
    }

    private synchronized void saveIfDirty() {
        if (!dirty) {
            saveTaskId = -1;
            return;
        }
        saveNow();
    }

    private void load() {
        ConfigurationSection rel = yaml.getConfigurationSection("relations");
        if (rel != null) {
            for (String key : rel.getKeys(false)) {
                relations.put(key, DiplomacyRelation.valueOf(rel.getString(key, "NEUTRAL")));
            }
        }
        ConfigurationSection req = yaml.getConfigurationSection("requests");
        if (req != null) {
            for (String key : req.getKeys(false)) {
                ConfigurationSection s = req.getConfigurationSection(key);
                if (s == null) continue;
                requests.add(new DiplomacyRequest(
                        s.getString("from", ""),
                        s.getString("to", ""),
                        DiplomacyRelation.valueOf(s.getString("type", "ALLY")),
                        s.getLong("created-at", System.currentTimeMillis())
                ));
            }
        }
    }
}
