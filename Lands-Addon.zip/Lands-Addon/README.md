# LandsNationBoost

Nation-based boost addon for **Paper/Spigot 1.21.x** with **Lands** integration.

## Features

- `/lands boost` GUI for nation boost activation.
- Nation boost storage (not player-only usage).
- Admin boost distribution to a player's nation.
- Config-driven boosts (effect, amplifier, duration, material, lore, cooldown, permission).
- Efficient timestamp-based active boost tracking.

## Commands

- `/lands boost`  
  Opens the nation boost GUI.
- `/lands boost give <player> <boost> <amount>`  
  Adds boost items to the player's nation storage.
- `/lands boost list`  
  Lists all configured boosts.
- `/lands boost reload`  
  Reloads configuration.

## Port Commands

- `/lands port`
- `/lands port menu`
- `/lands port list`
- `/lands port create <name>`
- `/lands port delete <name>`
- `/lands port info <name>`
- `/lands port travel <name>`
- `/lands port rename <oldName> <newName>`
- `/lands port setaccess <name> <private|nation|ally|public>`

## Port Admin Commands

- `/lands portadmin list`
- `/lands portadmin info <port>`
- `/lands portadmin teleport <port>`
- `/lands portadmin delete <port>`
- `/lands portadmin reload`
- `/lands portadmin forcecreate <name>`
- `/lands portadmin enable <port>`
- `/lands portadmin disable <port>`
- `/lands portadmin setcost <port> <amount>`
- `/lands portadmin setaccess <port> <private|nation|ally|public|admin_only>`
- `/lands portadmin setowner <port> <land|nation> <id>`

## Permission Overview

- `landsboost.use`  
  Allows using `/lands boost`.
- `landsboost.admin`  
  Full admin access to all admin subcommands/features.
- `landsboost.give`  
  Allows `/lands boost give`.
- `landsboost.reload`  
  Allows `/lands boost reload`.
- `landsboost.list`  
  Allows `/lands boost list`.
- `landsboost.bypasscooldown`  
  Allows activating boosts without cooldown checks.
- `landsnationboost.port.*`  
  Full port system permissions are documented in `plugin.yml` and `config.yml`.

## Build

1. Install **Java 21**.
2. Build with the Gradle wrapper:

```bash
./gradlew build
```

On Windows:

```cmd
gradlew.bat build
```

3. Use the generated plugin jar from:
   `build/libs/Lands-Addon-1.0.0.jar`
4. Copy that jar to your server `plugins/` folder.

## Add New Boosts

In `src/main/resources/config.yml`, add a new entry under `boosts:`:

- `display-name`
- `material`
- `lore`
- `effect-type`
- `amplifier`
- `duration-seconds`
- `allow-stack-with-other-active`
- `cooldown-seconds`
- `permission` (optional)

Then run `/lands boost reload`.
